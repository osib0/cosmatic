'use client';

import React from 'react';
import Image from 'next/image';
import { shopByCategories } from '@/data/products';

export default function CategoryShop() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 md:py-16">
      <div className="mb-8 sm:mb-10">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 heading-primary">
          Shop by Category
        </h2>
        <div className="w-16 sm:w-20 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mt-3 rounded-full"></div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
        {shopByCategories.map((category) => (
          <div
            key={category.id}
            className="group relative h-60 sm:h-64 md:h-72 rounded-xl overflow-hidden shadow-soft hover:shadow-lg-custom transition-all duration-300 hover:scale-105 cursor-pointer"
          >
            {/* Image */}
            <Image
              src={category.image}
              alt={category.name}
              fill
              className="object-cover group-hover:scale-110 transition-transform duration-500"
              sizes="(max-width: 768px) 50vw, 25vw"
            />

            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>

            {/* Content */}
            <div className="absolute inset-0 flex items-end p-4 sm:p-6">
              <div>
                <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-2">
                  {category.name}
                </h3>
                <button className="text-white text-sm sm:text-base font-semibold opacity-0 group-hover:opacity-100 transform transition-all duration-300 flex items-center gap-2 hover:translate-x-1">
                  Explore →
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
