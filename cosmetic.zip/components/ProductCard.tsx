'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import { Product } from '@/data/products';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false);

  return (
    <div className="group bg-white rounded-lg overflow-hidden shadow-soft hover:shadow-lg-custom transition-all duration-300 hover:scale-105 hover:z-10">
      {/* Image Container */}
      <div className="relative h-64 sm:h-56 md:h-64 bg-gray-100 overflow-hidden">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover group-hover:scale-110 transition-transform duration-500"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
        />

        {/* Discount Badge */}
        {product.discount && (
          <div className="absolute top-3 right-3 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold">
            {product.discount}% Off
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={() => setIsWishlisted(!isWishlisted)}
          className="absolute top-3 left-3 bg-white rounded-full p-2 shadow-md hover:shadow-lg transition-all hover:scale-110"
        >
          <Heart
            size={20}
            className={`transition-colors ${
              isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'
            }`}
          />
        </button>

        {/* Quick Actions Overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-300 flex items-end justify-center pb-4">
          <button className="bg-white text-purple-600 px-6 py-3 rounded-full font-semibold opacity-0 group-hover:opacity-100 transform transition-all duration-300 scale-75 group-hover:scale-100 flex items-center gap-2 hover:bg-gradient-to-r hover:from-purple-400 hover:to-pink-400 hover:text-white">
            <ShoppingCart size={18} />
            Add to Cart
          </button>
        </div>
      </div>

      {/* Product Info */}
      <div className="p-4">
        <h3 className="text-sm sm:text-base font-semibold text-gray-900 line-clamp-2 group-hover:text-purple-600 transition-colors">
          {product.name}
        </h3>

        {/* Rating */}
        <div className="flex items-center gap-1 my-2">
          <div className="flex items-center">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                size={14}
                className={`${
                  i < Math.floor(product.rating)
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-xs sm:text-sm text-gray-600">
            ({product.reviews})
          </span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2 my-3">
          <span className="text-lg sm:text-xl font-bold text-purple-600">
            ₹{product.price}
          </span>
          {product.originalPrice && (
            <span className="text-sm sm:text-base text-gray-500 line-through">
              ₹{product.originalPrice}
            </span>
          )}
        </div>

        {/* Add to Cart Button (Mobile) */}
        <button className="w-full sm:hidden bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2 rounded-lg font-semibold hover:shadow-lg transition-shadow">
          Add to Cart
        </button>
      </div>
    </div>
  );
}
