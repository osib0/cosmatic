'use client';

import React from 'react';
import BannerCard from './BannerCard';

export default function HeroSection() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 md:py-12">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
        {/* Left Card */}
        <div className="md:col-span-1">
          <BannerCard
            image="https://images.unsplash.com/photo-1596289519410-327aaf05dc47?w=500&h=500&fit=crop"
            title="Summer Glow Essentials"
            subtitle="Up to 40% Off"
            buttonText="Shop Now"
          />
        </div>

        {/* Center Card */}
        <div className="md:col-span-1">
          <BannerCard
            image="https://images.unsplash.com/photo-1570545063141-507f65b4ee0b?w=500&h=500&fit=crop"
            title="Serenlogue Beauty Awards 2026"
            subtitle="Vote Your Favorites"
            buttonText="Vote Now"
            isCenter
          />
        </div>

        {/* Right Card */}
        <div className="md:col-span-1">
          <BannerCard
            image="https://images.unsplash.com/photo-1596289519410-327aaf05dc47?w=500&h=500&fit=crop"
            title="Travel Beauty Kit"
            subtitle="Premium on-the-go collection"
            buttonText="Explore"
          />
        </div>
      </div>
    </section>
  );
}
