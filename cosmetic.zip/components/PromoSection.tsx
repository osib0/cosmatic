'use client';

import React from 'react';
import Image from 'next/image';

export default function PromoSection() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 md:py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 md:gap-10 items-center">
        {/* Left Side - Image */}
        <div className="relative h-64 sm:h-72 md:h-96 rounded-xl overflow-hidden shadow-medium hover:shadow-lg-custom transition-shadow group">
          <Image
            src="https://images.unsplash.com/photo-1570545063141-507f65b4ee0b?w=600&h=600&fit=crop"
            alt="Glow Naturally"
            fill
            className="object-cover group-hover:scale-110 transition-transform duration-500"
            sizes="(max-width: 768px) 100vw, 50vw"
          />
          <div className="absolute inset-0 bg-black/20"></div>
        </div>

        {/* Right Side - Content */}
        <div className="flex flex-col justify-center py-4 sm:py-8 md:py-0">
          <div className="w-16 sm:w-20 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mb-4"></div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-3 sm:mb-4 heading-primary">
            Glow Naturally
          </h2>

          <p className="text-base sm:text-lg text-gray-700 mb-4 sm:mb-6 leading-relaxed">
            Discover our exclusive collection of organic skincare products. Crafted with natural ingredients and backed by science, our range is perfect for all skin types. Experience the power of nature with our premium wellness products.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 sm:px-8 py-3 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300">
              Shop Collection
            </button>
            <button className="border-2 border-purple-500 text-purple-600 px-6 sm:px-8 py-3 rounded-full font-semibold hover:bg-purple-50 transition-colors duration-300">
              Learn More
            </button>
          </div>

          {/* Features */}
          <div className="mt-6 sm:mt-8 pt-6 sm:pt-8 border-t border-gray-300 flex flex-col sm:flex-row gap-4 sm:gap-8">
            <div>
              <p className="text-xl sm:text-2xl font-bold text-purple-600">100%</p>
              <p className="text-sm text-gray-700">Natural Ingredients</p>
            </div>
            <div>
              <p className="text-xl sm:text-2xl font-bold text-purple-600">Cruelty-Free</p>
              <p className="text-sm text-gray-700">Ethically Sourced</p>
            </div>
            <div>
              <p className="text-xl sm:text-2xl font-bold text-purple-600">Dermatologist</p>
              <p className="text-sm text-gray-700">Tested & Approved</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
