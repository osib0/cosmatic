'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Heart, Search, User, ShoppingCart, Menu, X } from 'lucide-react';

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Categories', href: '#' },
    { name: 'Brands', href: '#' },
    { name: 'Luxe', href: '#' },
    { name: 'Beauty Advice', href: '#' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-soft">
      {/* Top Navigation */}
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="text-2xl sm:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 hover:scale-105 transition-transform">
            serenlogue
          </Link>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex gap-8 items-center">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-gray-700 hover:text-purple-600 relative group transition-colors"
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-400 to-pink-400 group-hover:w-full transition-all duration-300"></span>
              </Link>
            ))}
          </div>

          {/* Right Icons and Search */}
          <div className="flex items-center gap-4 sm:gap-6">
            {/* Search Bar - Hidden on mobile */}
            <div className="hidden sm:flex items-center bg-gray-100 rounded-full px-4 py-2 flex-1 max-w-xs">
              <input
                type="text"
                placeholder="Search products..."
                className="bg-transparent outline-none text-sm flex-1 w-full"
              />
              <Search size={18} className="text-gray-500 cursor-pointer hover:text-purple-600 transition-colors" />
            </div>

            {/* Icons */}
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden sm:block">
              <Heart size={20} className="text-gray-700 hover:text-red-500 transition-colors" />
            </button>

            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden sm:block">
              <User size={20} className="text-gray-700 hover:text-purple-600 transition-colors" />
            </button>

            <button className="relative p-2 hover:bg-gray-100 rounded-full transition-colors">
              <ShoppingCart size={20} className="text-gray-700 hover:text-purple-600 transition-colors" />
              <span className="absolute top-1 right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                0
              </span>
            </button>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Search Bar for Mobile */}
        <div className="sm:hidden mt-4 flex items-center bg-gray-100 rounded-full px-4 py-2">
          <input
            type="text"
            placeholder="Search..."
            className="bg-transparent outline-none text-sm flex-1"
          />
          <Search size={18} className="text-gray-500" />
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 py-4 px-4 animate-fadeInUp">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className="block py-2 text-gray-700 hover:text-purple-600 transition-colors"
            >
              {link.name}
            </Link>
          ))}
          <div className="border-t mt-4 pt-4 flex gap-4">
            <button className="flex items-center gap-2 text-gray-700 hover:text-red-500">
              <Heart size={20} /> Wishlist
            </button>
            <button className="flex items-center gap-2 text-gray-700 hover:text-purple-600">
              <User size={20} /> Sign In
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
