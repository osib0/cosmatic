'use client';

import React from 'react';
import Image from 'next/image';

interface BannerCardProps {
  image: string;
  title: string;
  subtitle?: string;
  buttonText: string;
  isCenter?: boolean;
}

export default function BannerCard({
  image,
  title,
  subtitle,
  buttonText,
  isCenter,
}: BannerCardProps) {
  return (
    <div className="relative group overflow-hidden rounded-xl shadow-medium hover:shadow-lg-custom transition-all duration-300 hover:scale-105 h-96 sm:h-80 md:h-96">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src={image}
          alt={title}
          fill
          className="object-cover group-hover:scale-110 transition-transform duration-500"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors duration-300"></div>

      {/* Content */}
      <div className={`relative h-full flex flex-col justify-end p-4 sm:p-6 md:p-8 ${isCenter ? 'justify-center items-center text-center' : ''}`}>
        {isCenter ? (
          // Center Card Layout
          <div className="bg-white/95 backdrop-blur-sm rounded-lg p-6 sm:p-8 shadow-lg">
            <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 mb-2">
              {title}
            </h3>
            {subtitle && (
              <p className="text-sm sm:text-base text-gray-700 mb-4">
                {subtitle}
              </p>
            )}
            <button className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 sm:px-8 py-2 sm:py-3 rounded-full font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-300">
              {buttonText}
            </button>
          </div>
        ) : (
          // Side Card Layout
          <>
            <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-2 heading-primary">
              {title}
            </h3>
            {subtitle && (
              <p className="text-sm sm:text-base text-white/90 mb-4">
                {subtitle}
              </p>
            )}
            <button className="w-fit bg-white text-purple-600 px-6 sm:px-8 py-2 sm:py-3 rounded-full font-semibold hover:bg-gradient-to-r hover:from-purple-400 hover:to-pink-400 hover:text-white transform hover:scale-105 transition-all duration-300 shadow-lg">
              {buttonText}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
