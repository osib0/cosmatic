export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  discount?: number;
  isWishlisted?: boolean;
  category: string;
}

export const trendingProducts: Product[] = [
  {
    id: '1',
    name: 'Luxury Lip Tint',
    price: 599,
    originalPrice: 899,
    image: 'https://images.unsplash.com/photo-1596289519410-327aaf05dc47?w=400&h=400&fit=crop',
    rating: 4.5,
    reviews: 2340,
    discount: 33,
    category: 'Makeup',
  },
  {
    id: '2',
    name: 'Silk Pillowcase',
    price: 1299,
    originalPrice: 1899,
    image: 'https://images.unsplash.com/photo-1591290619762-a148b6151b01?w=400&h=400&fit=crop',
    rating: 4.8,
    reviews: 1856,
    discount: 31,
    category: 'Beauty',
  },
  {
    id: '3',
    name: 'Rose Gold Jade Roller',
    price: 799,
    originalPrice: 1199,
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400&h=400&fit=crop',
    rating: 4.6,
    reviews: 3421,
    discount: 33,
    category: 'Skincare',
  },
  {
    id: '4',
    name: 'Volumizing Mascara',
    price: 449,
    originalPrice: 699,
    image: 'https://images.unsplash.com/photo-1548068649-e4f66348f2b4?w=400&h=400&fit=crop',
    rating: 4.7,
    reviews: 4125,
    discount: 36,
    category: 'Makeup',
  },
  {
    id: '5',
    name: 'Hydrating Face Serum',
    price: 1099,
    originalPrice: 1799,
    image: 'https://images.unsplash.com/photo-1532883107881-4f94337dbb97?w=400&h=400&fit=crop',
    rating: 4.9,
    reviews: 5230,
    discount: 39,
    category: 'Skincare',
  },
  {
    id: '6',
    name: 'Night Cream',
    price: 899,
    originalPrice: 1399,
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&h=400&fit=crop',
    rating: 4.4,
    reviews: 2876,
    discount: 35,
    category: 'Skincare',
  },
  {
    id: '7',
    name: 'Luxury Hair Oil',
    price: 749,
    originalPrice: 1099,
    image: 'https://images.unsplash.com/photo-1596289519410-327aaf05dc47?w=400&h=400&fit=crop',
    rating: 4.6,
    reviews: 3654,
    discount: 32,
    category: 'Haircare',
  },
  {
    id: '8',
    name: 'Foundation Stick',
    price: 549,
    originalPrice: 899,
    image: 'https://images.unsplash.com/photo-1599599810794-f94f992e9953?w=400&h=400&fit=crop',
    rating: 4.7,
    reviews: 4532,
    discount: 39,
    category: 'Makeup',
  },
];

export const bestSellers: Product[] = [
  {
    id: '9',
    name: 'Vitamin C Cleanser',
    price: 649,
    originalPrice: 999,
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400&h=400&fit=crop',
    rating: 4.8,
    reviews: 6234,
    discount: 35,
    category: 'Skincare',
  },
  {
    id: '10',
    name: 'Eye Cream',
    price: 899,
    originalPrice: 1299,
    image: 'https://images.unsplash.com/photo-1570545063141-507f65b4ee0b?w=400&h=400&fit=crop',
    rating: 4.7,
    reviews: 3876,
    discount: 30,
    category: 'Skincare',
  },
  {
    id: '11',
    name: 'Setting Spray',
    price: 499,
    originalPrice: 799,
    image: 'https://images.unsplash.com/photo-1596289519410-327aaf05dc47?w=400&h=400&fit=crop',
    rating: 4.6,
    reviews: 2654,
    discount: 37,
    category: 'Makeup',
  },
  {
    id: '12',
    name: 'Lip Balm Set',
    price: 399,
    originalPrice: 699,
    image: 'https://images.unsplash.com/photo-1599599810694-f3ee39e00e81?w=400&h=400&fit=crop',
    rating: 4.5,
    reviews: 1876,
    discount: 43,
    category: 'Makeup',
  },
  {
    id: '13',
    name: 'Sunscreen SPF 50',
    price: 799,
    originalPrice: 1199,
    image: 'https://images.unsplash.com/photo-1550259987-3a8297e0e216?w=400&h=400&fit=crop',
    rating: 4.9,
    reviews: 5432,
    discount: 33,
    category: 'Skincare',
  },
  {
    id: '14',
    name: 'Moisturizer Lotion',
    price: 699,
    originalPrice: 1099,
    image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400&h=400&fit=crop',
    rating: 4.6,
    reviews: 4123,
    discount: 36,
    category: 'Skincare',
  },
];

export const shopByCategories = [
  {
    id: '1',
    name: 'Skincare',
    image: 'https://images.unsplash.com/photo-1570545063141-507f65b4ee0b?w=500&h=500&fit=crop',
  },
  {
    id: '2',
    name: 'Makeup',
    image: 'https://images.unsplash.com/photo-1596289519410-327aaf05dc47?w=500&h=500&fit=crop',
  },
  {
    id: '3',
    name: 'Haircare',
    image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=500&h=500&fit=crop',
  },
  {
    id: '4',
    name: 'Fragrance',
    image: 'https://images.unsplash.com/photo-1594945499941-9704cb73df0f?w=500&h=500&fit=crop',
  },
];
